# LandmarkVisibility
Group assignment for Computer Graphics course
